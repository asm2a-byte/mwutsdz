# MWUT-SDZ

Un package Python pour la détection automatique de knee point dans les données de batteries, basé sur le **Mann-Whitney U Test** et l’algorithme **SDZ**.

## Installation

Après publication sur PyPI :
```bash
pip install mwutsdz
